import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.Map;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Stack;

import org.objectweb.asm.commons.*;
import org.objectweb.asm.tree.*;

public class CFG {
	Set<Node> nodes = new HashSet<Node>();
	Map<Node, Set<Node>> edges = new HashMap<Node, Set<Node>>();

	static class Node {
		int position;
		MethodNode method;
		ClassNode clazz;

		Node(int p, MethodNode m, ClassNode c) {
			position = p;
			method = m;
			clazz = c;
		}

		public boolean equals(Object o) {
			if (!(o instanceof Node))
				return false;
			Node n = (Node) o;
			return (position == n.position) && method.equals(n.method)
					&& clazz.equals(n.clazz);
		}

		public int hashCode() {
			return position + method.hashCode() + clazz.hashCode();
		}

		public String toString() {
			return clazz.name + "." + method.name + method.signature + ": "
					+ position;
		}
	}

	public void addNode(int p, MethodNode m, ClassNode c) {
		addIfNotExist(p, m, c);
	}

	private Node findNode(Node n) {
		if (nodes.contains(n)) {
			for (Node obj : nodes) {
				if (obj.equals(n))
					return obj;
			}
		}
		return null;
	}

	private Node addIfNotExist(int p, MethodNode m, ClassNode c) {
		if (!nodes.contains(new Node(p, m, c))) {
			Node n = new Node(p, m, c);
			nodes.add(n);
			return n;
		}
		return findNode(new Node(p, m, c));
	}
	
	public void addEdge(int p1, MethodNode m1, ClassNode c1, int p2,
			MethodNode m2, ClassNode c2) {
		Node n1 = addIfNotExist(p1, m1, c1);
		Node n2 = addIfNotExist(p2, m2, c2);
		Set<Node> s1 = edges.get(n1);
		Set<Node> s2 = edges.get(n2);
		if (s1 == null) {
			s1 = new HashSet<Node>();
		}
		if (s2 == null) {
			s2 = new HashSet<Node>();
		}
		s1.add(n2);
		s2.add(n1);
		edges.put(n1, s1);
		edges.put(n2, s2);
	}

	public void deleteNode(int p, MethodNode m, ClassNode c) {
		Node n = findNode(new Node(p, m, c));
		if (n != null) {
			nodes.remove(n);
			edges.remove(n);

			for (Iterator<Entry<Node, Set<Node>>> it = edges.entrySet()
					.iterator(); it.hasNext();) {
				Entry<Node, Set<Node>> entry = it.next();
				Set<Node> s = entry.getValue();
				if (s == null) {
					it.remove();
				} else {
					s.remove(n);
				}
			}
		}
	}

	public void deleteEdge(int p1, MethodNode m1, ClassNode c1, int p2,
			MethodNode m2, ClassNode c2) {
		Node n1 = findNode(new Node(p1, m1, c1));
		Node n2 = findNode(new Node(p2, m2, c2));
		if (n1 != null && n2 != null) {
			for (Iterator<Entry<Node, Set<Node>>> it = edges.entrySet()
					.iterator(); it.hasNext();) {
				Entry<Node, Set<Node>> entry = it.next();
				Node n = entry.getKey();
				Set<Node> s = entry.getValue();
				if (s == null || n == null) {
					it.remove();
				} else if (n == n1 && s.contains(n2)) {
					s.remove(n2);
				} else if (n == n2 && s.contains(n1)) {
					s.remove(n1);
				}
			}
		}
	}

	public boolean isReachable(int p1, MethodNode m1, ClassNode c1, int p2,
			MethodNode m2, ClassNode c2) {
		
		Node n1 = findNode(new Node(p1, m1, c1));
		Node n2 = findNode(new Node(p2, m2, c2));
		
		Set<Node> search = new HashSet<Node>();
		Set<Node> reached = new HashSet<Node>();

		search.add(n1);
		
		while (!search.isEmpty()){
			Node n = search.iterator().next();;
			if (n == n2){
				return true;
			}else if (n == null){
				return false;
			}
			search.remove(n);
			if (!reached.contains(n)){
				reached.add(n);
				for (Node x : edges.get(n)){
					search.add(x);
				}
			}
		}
		return false;
	}
}
