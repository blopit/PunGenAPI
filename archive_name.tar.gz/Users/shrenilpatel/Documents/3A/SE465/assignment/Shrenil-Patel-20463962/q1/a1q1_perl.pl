#!/usr/bin/perl

print -5 % 2;