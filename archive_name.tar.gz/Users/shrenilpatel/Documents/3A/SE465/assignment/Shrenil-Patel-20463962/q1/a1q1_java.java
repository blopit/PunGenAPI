import java.util.*;

public class a1q1_java {
    public static void main(String args[]) {
        System.out.println(-5%2);
    }
}