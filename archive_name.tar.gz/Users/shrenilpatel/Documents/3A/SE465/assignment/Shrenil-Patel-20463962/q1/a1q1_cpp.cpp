#include <iostream>

int main(int argc, const char * argv[]) {
    std::cout << (-5 % 2);
    return 0;
}